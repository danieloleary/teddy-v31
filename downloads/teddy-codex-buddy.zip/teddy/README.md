# Teddy Codex Buddy

Teddy is a calm, dapper Codex buddy co-designed with OpenClaw: round glasses, a navy cardigan, a tiny iPad mini, and a warm cream sticker outline.

## Install

1. Unzip `teddy-codex-buddy.zip`.
2. Open the unzipped `teddy/` folder.
3. Copy only `pet.json` and `spritesheet.webp` into `~/.codex/pets/teddy/`.
4. Restart Codex if Teddy does not appear right away.
5. Select `Teddy` in Codex pets.

## Tell Codex To Install It

Paste this into Codex:

```text
Please install Teddy, my tiny Codex buddy, from:
https://danieloleary.github.io/teddy-v31/downloads/teddy-codex-buddy.zip

Download and unzip it, copy pet.json and spritesheet.webp into ~/.codex/pets/teddy/,
then verify the installed spritesheet hash matches the package manifest.
```

## What Is Inside

- `pet.json`: Teddy's Codex pet manifest.
- `spritesheet.webp`: Teddy's validated transparent animation atlas.
- `contact-sheet.png`: all animation frames in one image.
- `dark-before-after-spotcheck.png`: outline comparison on a dark background.
- `installed-validation.json`: atlas validation proof.
- `manifest.json`: hashes and package metadata.

Only `pet.json` and `spritesheet.webp` are needed for installation. The rest are previews, validation proof, and hashes.

## Validation

- Atlas: `1536x1872`
- Grid: `8x9`
- Cell: `192x208`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent residue: `0`
- Spritesheet SHA-256: `320be4f11d6ce14288e2756f972f2909231032259f5c297fd35271923efc8e64`

Do not send your whole `.codex` folder. This ZIP contains only Teddy's pet package, preview images, validation proof, and metadata.
