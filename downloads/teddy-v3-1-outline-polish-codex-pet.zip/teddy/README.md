# Teddy V3.1 Codex Pet

Teddy V3.1 is the current local Teddy pet: calm micro-expressions, dapper cardigan, round glasses, quiet iPad mini, and the new warm-cream sticker outline.

## What Changed

- Replaced the old pure-white/pink exterior halo with warm cream `#F2E6CB`
- Preserved Teddy's V3.1 identity, proportions, outfit, glasses, iPad mini, and all 9 animation states
- No character rebuild, no new props, no glow, no frame, no pink background

## Install

If someone sends you the ZIP:

1. Unzip `teddy-v3-1-outline-polish-codex-pet.zip`.
2. Open the unzipped `teddy/` folder.
3. Copy only `pet.json` and `spritesheet.webp` into:

```text
~/.codex/pets/teddy/
```

4. Restart Codex if Teddy does not appear right away.
5. Select `Teddy V3.1` in Codex pets.

The other files are just proof and previews:

- `contact-sheet.png`: all animation frames in one image
- `dark-before-after-spotcheck.png`: outline comparison on a dark background
- `installed-validation.json`: atlas validation proof
- `manifest.json`: hashes and package metadata

## Share With A Friend

Send this file:

```text
teddy-v3-1-outline-polish-codex-pet.zip
```

Do not send your whole `.codex` folder. This ZIP contains only Teddy's pet package, preview images, validation proof, and metadata.

## Validation

- Atlas: `1536x1872`
- Grid: `8x9`
- Cell: `192x208`
- Format: `WEBP`
- Mode: `RGBA`
- Transparent residue: `0`
- Spritesheet SHA-256: `320be4f11d6ce14288e2756f972f2909231032259f5c297fd35271923efc8e64`

## Preview

Use `dark-before-after-spotcheck.png` to compare the old halo against the warm-cream outline on a dark background.
